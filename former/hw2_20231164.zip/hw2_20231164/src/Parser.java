import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Parser {
    public static TokenList parse(InputHandler inputHandler) {
        TokenList tokenList = new TokenList();
        while (!inputHandler.reachEnd()) {
            // skip blanks
            if (Config.debugMode) System.out.println(inputHandler.getCurrentLine());
            if (inputHandler.skipBlanks()) break;
            if (Config.debugMode) System.out.println(inputHandler.getCurrentLine());

            // skip comments
            if (Config.debugMode) System.out.println(inputHandler.getCurrentLine());
            if (inputHandler.skipComments()) continue;
            if (Config.debugMode) System.out.println(inputHandler.getCurrentLine());
            // traverse all patterns and make regex match
            for (Type type : Type.values()) {
                Matcher matcher = Pattern.compile(type.getPattern()).matcher(inputHandler.getCurrentLine());
                if (matcher.find()) {
                    if (Config.debugMode) System.out.println(inputHandler.getCurrentLine());
                    tokenList.add(new Token(type, matcher.group(0), inputHandler.getLineNumber()));
                    if (Config.debugMode) System.out.println(inputHandler.getCurrentLine());
                    inputHandler.moveForward(matcher.group(0).length());
                    if (Config.debugMode) System.out.println(inputHandler.getCurrentLine());
                    break;
                }
            }
        }
        return tokenList;
    }
}
