public class Token {
    private Type type;
    private int line;
    private String content;

    public Token(Type type, String content, int line) {
        this.type = type;
        this.content = content;
        this.line = line;
    }

    public String getTypeName() {
        return this.type.toString();
    }

    public String getContent() {
        return this.content;
    }

    public int getLine() {
        return line;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public void setLine(int line) {
        this.line = line;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
