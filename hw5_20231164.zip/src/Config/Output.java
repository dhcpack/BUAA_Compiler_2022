package Config;

public interface Output {
    public void output();
}
