// package Middle.type;
//
// public class Def {
// }
