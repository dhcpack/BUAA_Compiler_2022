package Middle.type;

public interface BlockNode {
}
