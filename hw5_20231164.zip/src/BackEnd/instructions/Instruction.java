package BackEnd.instructions;

/*
 * 指令
 * */
public interface Instruction {
    String toString();
}
