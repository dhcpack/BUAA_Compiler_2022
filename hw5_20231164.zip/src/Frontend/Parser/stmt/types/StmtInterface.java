package Frontend.Parser.stmt.types;

public interface StmtInterface {
    void output();

    int getSemicolonLine();
}
