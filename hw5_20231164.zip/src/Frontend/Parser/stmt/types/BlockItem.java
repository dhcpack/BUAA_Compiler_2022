package Frontend.Parser.stmt.types;

public interface BlockItem {
    public void output();
}
