package Parser.stmt.types;

public interface StmtInterface {
    void output();

    int getSemicolonLine();
}
