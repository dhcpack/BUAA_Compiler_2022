package Parser;

public interface Output {
    public void output();
}
