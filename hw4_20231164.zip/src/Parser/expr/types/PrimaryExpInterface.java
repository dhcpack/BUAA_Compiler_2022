package Parser.expr.types;

// PrimaryExp → BraceExp | LVal | Number
public interface PrimaryExpInterface {
    void output();

    int getLine();
}
