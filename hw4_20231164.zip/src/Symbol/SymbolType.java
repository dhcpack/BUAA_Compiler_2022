package Symbol;

public enum SymbolType {
    INT,
    ARRAY,
    FUNCTION,
    VOID,
}
