package Config;

public class Config {
    public static boolean debugMode = false;
    private static final String[] inputFiles = {"../2022-testfiles/testfiles-only/C/testfile6.txt", "testfile.txt"};
    public static String inputFile = debugMode ? inputFiles[0] : inputFiles[1];
    public static String outputFile = "output.txt";
}
