package Parser.stmt.types;

import Parser.Output;

public interface StmtInterface {
    public void output();
}
