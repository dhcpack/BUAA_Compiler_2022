package Parser.expr.types;

// PrimaryExp → '(' Exp ')' | LVal | Number
public interface PrimaryExpInterface {
    public void output();
}
