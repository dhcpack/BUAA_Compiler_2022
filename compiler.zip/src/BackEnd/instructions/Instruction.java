package BackEnd.instructions;

/*
 * 指令
 * */
public interface Instruction {
    double getCost();
    String toString();
}
