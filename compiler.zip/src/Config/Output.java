package Config;

public interface Output {
    void output();
}
