package Middle.optimizer;

public class MergeBranch {
    /*
    *
        # EQ, INT(ti_16[temp]), INT(k[sp-0x20]), 4
        seq $17, $12, 4
        # Branch INT(ti_16[temp]) ? IF_BODY_42 : IF_END_44
        beq $17, $0, IF_END_44
    *
    * */
}
