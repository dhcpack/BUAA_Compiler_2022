package Middle.type;

public interface Operand {
    String toString();
}
