package Exceptions;

public interface MyException{
    public ErrorType getType();

    public int getLine();
}
