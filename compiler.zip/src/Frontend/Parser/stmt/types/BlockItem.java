package Frontend.Parser.stmt.types;

public interface BlockItem {
}
