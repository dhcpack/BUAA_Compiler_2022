package Frontend.Parser.stmt.types;

public interface StmtInterface {
    int getSemicolonLine();
}
