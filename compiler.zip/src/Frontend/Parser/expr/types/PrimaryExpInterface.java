package Frontend.Parser.expr.types;

// PrimaryExp → BraceExp | LVal | Number
public interface PrimaryExpInterface {
    int getLine();
}
