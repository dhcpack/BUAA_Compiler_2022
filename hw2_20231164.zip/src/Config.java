public class Config {
    // public static String inputFile = "../2021testfiles/full/A/testfile21.txt";
    public static String inputFile = "testfile.txt";
    public static String outputFile = "output.txt";
    public static boolean debugMode = true;
}
